"""
Core module for AI Game
"""
