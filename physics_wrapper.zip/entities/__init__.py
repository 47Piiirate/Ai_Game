"""
Entities module for AI Game
"""
