"""
Graphics module for AI Game
"""
