Download or create the following sound assets:

1. jump.wav - Jump sound effect
2. dash.wav - Dash sound
3. attack.wav - Attack sound
4. hit.wav - Hit/damage sound
5. parry.wav - Parry sound
6. collect.wav - Collectible pickup
7. death.wav - Death sound
8. menu_select.wav - Menu selection
9. boss_hit.wav - Hitting a boss
10. ability_unlock.wav - Unlocking new ability

Recommended style:
- Punk rock influences
- Digital/electronic sound effects
- Skateboard sounds for movement
