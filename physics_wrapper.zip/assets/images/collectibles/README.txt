Create the following collectible assets:

1. health.png - Health pickup (20x20px)
2. coin.png - Collectible coin (20x20px)

Format: Single image files for each collectible
