Create the following enemy assets:

1. enemy.png - Regular enemy sprite (50x50px)
2. boss.png - Boss enemy sprite (100x100px)

Format: Single image files for each enemy type
