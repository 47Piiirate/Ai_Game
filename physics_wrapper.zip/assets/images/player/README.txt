Create the following player assets:

1. player_idle.png - Idle animation (8 frames, 50x50px each)
2. player_run.png - Run animation (8 frames, 50x50px each) 
3. player_jump.png - Jump animation (4 frames, 50x50px each)

Format: Horizontal sprite sheets with frames side by side
