Download or create the following UI assets:

1. health_bar.png - Health bar frame
2. stamina_bar.png - Stamina bar
3. button.png - Menu button
4. menu_bg.png - Menu background
5. icon_dash.png, icon_jump.png, etc. - Ability icons

Recommended style:
- Punk/graffiti aesthetic
- Distressed or spraypaint look
- High contrast for readability
