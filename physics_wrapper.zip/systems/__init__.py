"""
Systems module for AI Game
"""
