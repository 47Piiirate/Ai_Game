#include <Python.h>
#include <vector>
#include <cmath>

// Structure to represent a rectangle for collision detection
typedef struct {
    float x, y, width, height;
} Rect;

// Check if two rectangles intersect
static bool rect_intersect(const Rect& a, const Rect& b) {
    return (a.x < b.x + b.width &&
            a.x + a.width > b.x &&
            a.y < b.y + b.height &&
            a.y + a.height > b.y);
}

// Function to sweep test a moving rectangle against a static rectangle
static PyObject* physics_sweep_test(PyObject* self, PyObject* args) {
    float player_x, player_y, player_width, player_height;
    float player_vx, player_vy;
    PyObject* obstacles_list;
    
    // Parse arguments
    if (!PyArg_ParseTuple(args, "ffffff0",
                          &player_x, &player_y, &player_width, &player_height,
                          &player_vx, &player_vy, &obstacles_list)) {
        return NULL;
    }
    
    // Ensure obstacles_list is a list
    if (!PyList_Check(obstacles_list)) {
        PyErr_SetString(PyExc_TypeError, "Obstacles must be a list");
        return NULL;
    }
    
    // Create the player rect
    Rect player = {player_x, player_y, player_width, player_height};
    
    // Create a list to store obstacles
    std::vector<Rect> obstacles;
    int num_obstacles = PyList_Size(obstacles_list);
    
    for (int i = 0; i < num_obstacles; i++) {
        PyObject* rect_tuple = PyList_GetItem(obstacles_list, i);
        if (!PyTuple_Check(rect_tuple) || PyTuple_Size(rect_tuple) != 4) {
            PyErr_SetString(PyExc_TypeError, "Each obstacle must be a tuple of (x, y, width, height)");
            return NULL;
        }
        
        float x = (float)PyFloat_AsDouble(PyTuple_GetItem(rect_tuple, 0));
        float y = (float)PyFloat_AsDouble(PyTuple_GetItem(rect_tuple, 1));
        float width = (float)PyFloat_AsDouble(PyTuple_GetItem(rect_tuple, 2));
        float height = (float)PyFloat_AsDouble(PyTuple_GetItem(rect_tuple, 3));
        
        obstacles.push_back({x, y, width, height});
    }
    
    // Implement sweep test for more accurate collision detection
    float time_x = 1.0f, time_y = 1.0f;
    int hit_x = -1, hit_y = -1;
    
    // Check collision in X direction
    if (player_vx != 0) {
        for (size_t i = 0; i < obstacles.size(); i++) {
            const Rect& obstacle = obstacles[i];
            float t;
            
            if (player_vx > 0) {
                t = (obstacle.x - (player.x + player.width)) / player_vx;
            } else {
                t = ((obstacle.x + obstacle.width) - player.x) / player_vx;
            }
            
            if (t >= 0 && t < time_x) {
                float y_at_collision = player.y + player_vy * t;
                if (y_at_collision + player.height > obstacle.y && 
                    y_at_collision < obstacle.y + obstacle.height) {
                    time_x = t;
                    hit_x = i;
                }
            }
        }
    }
    
    // Check collision in Y direction
    if (player_vy != 0) {
        for (size_t i = 0; i < obstacles.size(); i++) {
            const Rect& obstacle = obstacles[i];
            float t;
            
            if (player_vy > 0) {
                t = (obstacle.y - (player.y + player.height)) / player_vy;
            } else {
                t = ((obstacle.y + obstacle.height) - player.y) / player_vy;
            }
            
            if (t >= 0 && t < time_y) {
                float x_at_collision = player.x + player_vx * t;
                if (x_at_collision + player.width > obstacle.x && 
                    x_at_collision < obstacle.x + obstacle.width) {
                    time_y = t;
                    hit_y = i;
                }
            }
        }
    }
    
    // Determine the final movement
    float final_x = player_x;
    float final_y = player_y;
    bool collided_x = false;
    bool collided_y = false;
    
    if (hit_x >= 0 && time_x < 1.0f) {
        final_x += player_vx * time_x;
        collided_x = true;
    } else {
        final_x += player_vx;
    }
    
    if (hit_y >= 0 && time_y < 1.0f) {
        final_y += player_vy * time_y;
        collided_y = true;
    } else {
        final_y += player_vy;
    }
    
    // Create and return result tuple: (final_x, final_y, collided_x, collided_y)
    return Py_BuildValue("ffii", final_x, final_y, collided_x, collided_y);
}

// Function to check if player is on ground
static PyObject* physics_check_on_ground(PyObject* self, PyObject* args) {
    float player_x, player_y, player_width, player_height;
    PyObject* obstacles_list;
    float check_distance = 1.0f;  // Distance to check below player
    
    // Parse arguments
    if (!PyArg_ParseTuple(args, "ffff0|f",
                          &player_x, &player_y, &player_width, &player_height,
                          &obstacles_list, &check_distance)) {
        return NULL;
    }
    
    // Create player rect
    Rect player = {player_x, player_y, player_width, player_height};
    
    // Create ground check rect (just below player)
    Rect ground_check = {player_x, player_y + player_height, player_width, check_distance};
    
    // Check each obstacle
    int num_obstacles = PyList_Size(obstacles_list);
    for (int i = 0; i < num_obstacles; i++) {
        PyObject* rect_tuple = PyList_GetItem(obstacles_list, i);
        
        float x = (float)PyFloat_AsDouble(PyTuple_GetItem(rect_tuple, 0));
        float y = (float)PyFloat_AsDouble(PyTuple_GetItem(rect_tuple, 1));
        float width = (float)PyFloat_AsDouble(PyTuple_GetItem(rect_tuple, 2));
        float height = (float)PyFloat_AsDouble(PyTuple_GetItem(rect_tuple, 3));
        
        Rect obstacle = {x, y, width, height};
        
        if (rect_intersect(ground_check, obstacle)) {
            Py_RETURN_TRUE;
        }
    }
    
    Py_RETURN_FALSE;
}

// Module method table
static PyMethodDef PhysicsMethods[] = {
    {"sweep_test", physics_sweep_test, METH_VARARGS, "Perform a sweep test for collision detection"},
    {"check_on_ground", physics_check_on_ground, METH_VARARGS, "Check if the player is on the ground"},
    {NULL, NULL, 0, NULL}  // Sentinel
};

// Module definition
static struct PyModuleDef physicsmodule = {
    PyModuleDef_HEAD_INIT,
    "physics_engine",   // Module name
    "C extension for game physics calculations",  // Module docstring
    -1,                 // Size of per-interpreter state or -1
    PhysicsMethods      // Method table
};

// Module initialization function
PyMODINIT_FUNC PyInit_physics_engine(void) {
    return PyModule_Create(&physicsmodule);
}
