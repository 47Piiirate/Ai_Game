"""
Utils module for AI Game
"""
